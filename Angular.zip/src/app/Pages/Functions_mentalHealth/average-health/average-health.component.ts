import { Component } from '@angular/core';

@Component({
  selector: 'app-average-health',
  standalone: true,
  imports: [],
  templateUrl: './average-health.component.html',
  styleUrl: './average-health.component.css'
})
export class AverageHealthComponent {

}
