import { Component } from '@angular/core';

@Component({
  selector: 'app-good-health',
  standalone: true,
  imports: [],
  templateUrl: './good-health.component.html',
  styleUrl: './good-health.component.css'
})
export class GoodHealthComponent {

}
