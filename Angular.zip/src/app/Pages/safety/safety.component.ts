import { Component } from '@angular/core';

@Component({
  selector: 'app-safety',
  standalone: true,
  imports: [],
  templateUrl: './safety.component.html',
  styleUrl: './safety.component.css'
})
export class SafetyComponent {

}
